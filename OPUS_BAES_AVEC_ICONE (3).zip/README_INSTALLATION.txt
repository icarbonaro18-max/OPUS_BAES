OPUS BAES — installation de l’icône

1. Envoyer à la racine du dépôt GitHub OPUS_BAES : index.html, manifest.webmanifest, icon-192.png, icon-512.png, apple-touch-icon.png, favicon-64.png.
2. Commit puis attendre le redéploiement GitHub Pages.
3. Android/Samsung : supprimer l’ancien raccourci, ouvrir le site dans Chrome, menu ⋮ > Installer l’application / Ajouter à l’écran d’accueil.
4. iPhone/iPad : supprimer l’ancien raccourci, ouvrir le site dans Safari, Partager > Sur l’écran d’accueil.
